import axios from "axios";

const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000/api",
});

api.interceptors.request.use((config) => {
  if (typeof window !== "undefined") {
    const token = localStorage.getItem("sz_access");
    if (token) config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default api;
